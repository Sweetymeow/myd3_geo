For an explanation of topology construction, see
[How To Infer Topology](http://bost.ocks.org/mike/topology/).
